from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from datetime import datetime
import pyodbc

app = Flask(__name__)
app.secret_key = "lpg_secret_key"

# ---------- Database Configuration ----------
DB_DSN = "LPG_LOCAL"     # Your ODBC DSN name
DB_USER = "system"        # Oracle username
DB_PASSWORD = "system123" # Oracle password
# --------------------------------------------

def get_db_connection():
    conn_str = f"DSN={DB_DSN};UID={DB_USER};PWD={DB_PASSWORD}"
    return pyodbc.connect(conn_str)


# ------------------ LOGIN ------------------
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form.get('userid')
        pwd = request.form.get('password')
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("SELECT PASSWORD FROM APP_USERS WHERE USER_ID = ?", (user,))
            row = cur.fetchone()
            conn.close()
        except Exception as e:
            return render_template('login.html', error=f"DB error: {e}")
        if row and row[0] == pwd:
            session['user'] = user
            return redirect(url_for('booking_form'))
        else:
            return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))


# ------------------ PAGES ------------------
@app.route('/booking')
def booking_form():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('booking.html')


# ------------------ Generate BOOKING_ID (sequence) ------------------
@app.route('/generate_booking_id', methods=['GET'])
def generate_booking_id():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT SEQ_BOOKING_ID.NEXTVAL FROM DUAL")
        nxt = cur.fetchone()[0]
        conn.close()
        return jsonify({'booking_id': int(nxt)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ------------------ Insert or Update into BOOKING_BUFFER ------------------
@app.route('/save_to_buffer', methods=['POST'])
def save_to_buffer():
    """
    Insert or update into BOOKING_BUFFER.
    If BOOKING_ID exists in BOOKING_MAIN -> reject (committed).
    If BOOKING_ID exists in BOOKING_BUFFER -> update.
    Otherwise insert.
    """
    try:
        data = request.get_json() or request.form.to_dict()
        def g(k): return data.get(k) or data.get(k.lower()) or data.get(k.upper())

        booking_id = g('booking_id')
        conn = get_db_connection()
        cur = conn.cursor()

        # If the booking is already in main, do not allow changes
        if booking_id:
            cur.execute("SELECT 1 FROM BOOKING_MAIN WHERE BOOKING_ID = ?", (int(booking_id),))
            if cur.fetchone():
                conn.close()
                return jsonify({'error': 'Record already committed and cannot be modified.'}), 400

        # Required fields and types
        customer_id = int(g('customer_id') or 0)
        booking_date_raw = g('booking_date')
        delivery_date_raw = g('delivery_date')
        quantity = int(g('quantity') or 0)
        price = float(g('price_per_cylinder') or 0.0)
        total_amount = quantity * price
        delivery_charge = total_amount + 50  # as requested
        delivery_status = g('delivery_status') or 'Booked'
        days_to_deliver = int(g('days_to_deliver') or 0)
        payment_mode = g('payment_mode') or 'Cash'

        # parse dates
        booking_date = datetime.strptime(booking_date_raw, '%Y-%m-%d').date() if booking_date_raw else datetime.now().date()
        delivery_date = datetime.strptime(delivery_date_raw, '%Y-%m-%d').date() if delivery_date_raw else None

        # Generate booking_id if not provided (this endpoint can generate & insert)
        if not booking_id:
            cur.execute("SELECT SEQ_BOOKING_ID.NEXTVAL FROM DUAL")
            booking_id = cur.fetchone()[0]

        # Check existence in buffer
        cur.execute("SELECT 1 FROM BOOKING_BUFFER WHERE BOOKING_ID = ?", (int(booking_id),))
        in_buffer = cur.fetchone() is not None

        if in_buffer:
            # update
            cur.execute("""
                UPDATE BOOKING_BUFFER SET
                    CUSTOMER_ID=?, BOOKING_DATE=?, DELIVERY_DATE=?, QUANTITY=?,
                    PRICE_PER_CYLINDER=?, TOTAL_AMOUNT=?, DELIVERY_STATUS=?, DAYS_TO_DELIVER=?, PAYMENT_MODE=?, Delivery_charge=?
                WHERE BOOKING_ID=?
            """, (customer_id, booking_date, delivery_date, quantity, price, total_amount,
                  delivery_status, days_to_deliver, payment_mode, delivery_charge, int(booking_id)))
            message = f"Updated BOOKING_BUFFER {booking_id}"
        else:
            # insert
            cur.execute("""
                INSERT INTO BOOKING_BUFFER (
                    BOOKING_ID, CUSTOMER_ID, BOOKING_DATE, DELIVERY_DATE, QUANTITY,
                    PRICE_PER_CYLINDER, TOTAL_AMOUNT, DELIVERY_STATUS, DAYS_TO_DELIVER, PAYMENT_MODE, Delivery_charge
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (int(booking_id), customer_id, booking_date, delivery_date, quantity,
                  price, total_amount, delivery_status, days_to_deliver, payment_mode, delivery_charge))
            message = f"Inserted into BOOKING_BUFFER with ID {booking_id}"

        conn.commit()
        conn.close()
        return jsonify({'message': message, 'booking_id': int(booking_id)})
    except Exception as e:
        try:
            conn.rollback()
            conn.close()
        except:
            pass
        import traceback
        print("Error Traceback:\n", traceback.format_exc())
        return jsonify({'error': f'{type(e)}: {e}'}), 500


# ------------------ Get single record from BOOKING_BUFFER ------------------
@app.route('/get_record', methods=['GET'])
def get_record():
    booking_id = request.args.get('booking_id')
    if not booking_id:
        return jsonify({'error': 'booking_id required'}), 400
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM BOOKING_BUFFER WHERE BOOKING_ID = ?", (int(booking_id),))
        row = cur.fetchone()
        conn.close()
        if not row:
            return jsonify({'error': 'Not found'}), 404
        record = {
            'booking_id': row[0],
            'customer_id': row[1],
            'booking_date': row[2].strftime('%Y-%m-%d') if row[2] else '',
            'delivery_date': row[3].strftime('%Y-%m-%d') if row[3] else '',
            'quantity': row[4],
            'price_per_cylinder': row[5],
            'total_amount': row[6],
            'delivery_status': row[7],
            'days_to_deliver': row[8],
            'payment_mode': row[9],
            'delivery_charge': row[10]
        }
        return jsonify({'success': True, 'record': record})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ------------------ Prev / Next ------------------
@app.route('/get_previous_record', methods=['GET'])
def get_previous_record():
    current_id = request.args.get('current_id', type=int)
    if current_id is None:
        return jsonify({'error': 'current_id required'}), 400
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT * FROM (
                SELECT * FROM BOOKING_BUFFER
                WHERE BOOKING_ID < ?
                ORDER BY BOOKING_ID DESC
            ) WHERE ROWNUM = 1
        """, (current_id,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return jsonify({'error': 'No previous record'}), 404
        record = {
            'booking_id': row[0],
            'customer_id': row[1],
            'booking_date': row[2].strftime('%Y-%m-%d') if row[2] else '',
            'delivery_date': row[3].strftime('%Y-%m-%d') if row[3] else '',
            'quantity': row[4],
            'price_per_cylinder': row[5],
            'total_amount': row[6],
            'delivery_status': row[7],
            'days_to_deliver': row[8],
            'payment_mode': row[9],
            'delivery_charge': row[10]
        }
        return jsonify({'success': True, 'record': record})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_next_record', methods=['GET'])
def get_next_record():
    current_id = request.args.get('current_id', type=int)
    if current_id is None:
        return jsonify({'error': 'current_id required'}), 400
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT * FROM (
                SELECT * FROM BOOKING_BUFFER
                WHERE BOOKING_ID > ?
                ORDER BY BOOKING_ID ASC
            ) WHERE ROWNUM = 1
        """, (current_id,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return jsonify({'error': 'No next record'}), 404
        record = {
            'booking_id': row[0],
            'customer_id': row[1],
            'booking_date': row[2].strftime('%Y-%m-%d') if row[2] else '',
            'delivery_date': row[3].strftime('%Y-%m-%d') if row[3] else '',
            'quantity': row[4],
            'price_per_cylinder': row[5],
            'total_amount': row[6],
            'delivery_status': row[7],
            'days_to_deliver': row[8],
            'payment_mode': row[9],
            'delivery_charge': row[10]
        }
        return jsonify({'success': True, 'record': record})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
# ------------------ Update existing record in BOOKING_BUFFER ------------------
@app.route('/update_record', methods=['POST'])
def update_record():
    """
    Updates an existing booking record in BOOKING_BUFFER.
    User must provide booking_id and at least one field to update.
    """
    try:
        data = request.get_json() or request.form.to_dict()
        def g(k): return data.get(k) or data.get(k.lower()) or data.get(k.upper())

        booking_id = g('booking_id')
        if not booking_id:
            return jsonify({'error': 'booking_id required'}), 400

        conn = get_db_connection()
        cur = conn.cursor()

        # Ensure record exists in BOOKING_BUFFER (not yet committed)
        cur.execute("SELECT 1 FROM BOOKING_BUFFER WHERE BOOKING_ID = ?", (int(booking_id),))
        if not cur.fetchone():
            conn.close()
            return jsonify({'error': f'Booking ID {booking_id} not found in buffer.'}), 404

        # Extract fields (update only non-empty ones)
        updates = []
        values = []

        fields = {
            'CUSTOMER_ID': g('customer_id'),
            'BOOKING_DATE': g('booking_date'),
            'DELIVERY_DATE': g('delivery_date'),
            'QUANTITY': g('quantity'),
            'PRICE_PER_CYLINDER': g('price_per_cylinder'),
            'DELIVERY_STATUS': g('delivery_status'),
            'DAYS_TO_DELIVER': g('days_to_deliver'),
            'PAYMENT_MODE': g('payment_mode')
        }

        for col, val in fields.items():
            if val not in [None, '', 'null']:
                updates.append(f"{col} = ?")
                # Convert types properly
                if col in ['QUANTITY', 'CUSTOMER_ID', 'DAYS_TO_DELIVER']:
                    values.append(int(val))
                elif col in ['PRICE_PER_CYLINDER']:
                    values.append(float(val))
                elif col in ['BOOKING_DATE', 'DELIVERY_DATE']:
                    values.append(datetime.strptime(val, '%Y-%m-%d').date())
                else:
                    values.append(val)

        if not updates:
            conn.close()
            return jsonify({'error': 'No fields to update'}), 400

        # Calculate new total and delivery charge if quantity or price changed
        if 'QUANTITY' in fields and 'PRICE_PER_CYLINDER' in fields:
            quantity = int(g('quantity') or 0)
            price = float(g('price_per_cylinder') or 0)
            total = quantity * price
            delivery_charge = total + 50
            updates.append("TOTAL_AMOUNT = ?")
            updates.append("REMAINING_AMOUNT = ?")
            values.append(total)
            values.append(delivery_charge)

        # Execute update
        query = f"UPDATE BOOKING_BUFFER SET {', '.join(updates)} WHERE BOOKING_ID = ?"
        values.append(int(booking_id))
        cur.execute(query, tuple(values))
        conn.commit()
        conn.close()

        return jsonify({'message': f'Booking ID {booking_id} updated successfully.'})
    except Exception as e:
        try:
            conn.rollback()
            conn.close()
        except:
            pass
        import traceback
        print(traceback.format_exc())
        return jsonify({'error': str(e)}), 500



# ------------------ Delete ------------------
@app.route('/delete_from_database', methods=['DELETE'])
def delete_from_database():
    try:
        data = request.get_json()
        booking_id = data.get('booking_id')
        if not booking_id:
            return jsonify({'error': 'booking_id required'}), 400
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM BOOKING_BUFFER WHERE BOOKING_ID = ?", (int(booking_id),))
        cur.execute("DELETE FROM BOOKING_MAIN WHERE BOOKING_ID = ?", (int(booking_id),))
        conn.commit()
        conn.close()
        return jsonify({'message': f'Booking ID {booking_id} deleted.'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ------------------ Commit all ------------------
@app.route('/commit_all', methods=['POST'])
def commit_all():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("INSERT INTO BOOKING_MAIN SELECT * FROM BOOKING_BUFFER")
        cur.execute("DELETE FROM BOOKING_BUFFER")
        conn.commit()
        conn.close()
        return jsonify({'message': 'All buffer records moved to main.'})
    except Exception as e:
        try:
            conn.rollback()
            conn.close()
        except:
            pass
        return jsonify({'error': str(e)}), 500


# ------------------ View helpers ------------------
@app.route('/get_all_book_ids', methods=['GET'])
def get_all_book_ids():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT BOOKING_ID FROM BOOKING_BUFFER ORDER BY BOOKING_ID")
        ids = [r[0] for r in cur.fetchall()]
        conn.close()
        return jsonify({'book_ids': ids})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/show_buffer')
def show_buffer():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM BOOKING_BUFFER ORDER BY BOOKING_ID")
        rows = cur.fetchall()
        cols = [d[0] for d in cur.description]
        conn.close()
        html = "<h3>BOOKING_BUFFER</h3><table border='1'><tr>" + "".join(f"<th>{c}</th>" for c in cols) + "</tr>"
        for r in rows:
            html += "<tr>" + "".join(f"<td>{v}</td>" for v in r) + "</tr>"
        html += "</table>"
        return html
    except Exception as e:
        return f"Error: {e}", 500

@app.route('/show_main')
def show_main():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM BOOKING_MAIN ORDER BY BOOKING_ID")
        rows = cur.fetchall()
        cols = [d[0] for d in cur.description]
        conn.close()
        html = "<h3>BOOKING_MAIN</h3><table border='1'><tr>" + "".join(f"<th>{c}</th>" for c in cols) + "</tr>"
        for r in rows:
            html += "<tr>" + "".join(f"<td>{v}</td>" for v in r) + "</tr>"
        html += "</table>"
        return html
    except Exception as e:
        return f"Error: {e}", 500
    




if __name__ == '__main__':
    app.run(debug=True)
